export const CLINIC_NAME = 'ORTHONOVA POLYCLINIC';
export const CLINIC_REG_NO = 'Regd. No: XXXXX';
export const CLINIC_ADDRESS_LINE_1 = '123, Main Street, City';
export const CLINIC_ADDRESS_LINE_2 = 'State, Country - 000000';
export const CLINIC_CONTACT = 'Phone: +91-90000 00000 | Email: info@orthonova.example';
export const CLINIC_FOOTER = 'Thank you for choosing OrthoNova Polyclinic';